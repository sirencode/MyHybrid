/**
 * 定义与Native调用js相关的事件监听
 */
 function testAlert() {
     alert("native 调用 JS");
 }